using CafeManagementSystem.adminFlow;
using CafeManagementSystem.auth;
using CafeManagementSystem.UserFlow;
using System.Data;
using System.Data.SqlClient;

namespace CafeManagementSystem
{
    public partial class Form1 : Form
    {
       static  string conStr = "Data Source=MAC4C34\\SQLEXPRESS;Initial Catalog=CafeManagementSystem;Integrated Security=True";
       static SqlConnection con = new SqlConnection(conStr);
        
        
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
          
        }
        private void signIn_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                string username = usernameTxtBox.Text;
                string password = passwordTextBox.Text;

                string q = "SELECT * FROM GetLoginData(@Username, @Password)";
                SqlCommand cmd = new SqlCommand(q, con);

                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);

                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.Read()) 
                {
                    int id = Convert.ToInt32(sdr["Id"]);
                    string name = sdr["Username"].ToString();
                    string role = sdr["Role"].ToString();

                    sdr.Close();
                    con.Close();

                    if (role == "Admin")
                    {
                        AdminDashBoard adminDashBoard = new AdminDashBoard();
                        adminDashBoard.Show();
                        this.Hide();
                    }
                    else if (role == "Customer")
                    {
                        UserDashBoardForm userDashBoardForm = new UserDashBoardForm(id, name);
                        userDashBoardForm.Show();
                        this.Hide();
                    }
                }
                else
                {
                    sdr.Close();
                    con.Close();

                    MessageBox.Show("Invalid username or password!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void signUp_Click(object sender, EventArgs e)
        {
           SignUpForm signUpForm = new SignUpForm();
            signUpForm.Show();
            this.Hide();
        }

    }
}
