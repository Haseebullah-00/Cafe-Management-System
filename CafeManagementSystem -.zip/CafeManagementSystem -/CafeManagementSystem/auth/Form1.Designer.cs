﻿namespace CafeManagementSystem
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            panel1 = new Panel();
            signUp = new Label();
            label4 = new Label();
            signIn = new Button();
            passwordTextBox = new TextBox();
            label3 = new Label();
            usernameTxtBox = new TextBox();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(580, 301);
            label1.Name = "label1";
            label1.Size = new Size(359, 61);
            label1.TabIndex = 0;
            label1.Text = "Welcome Back";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(23, 23, 23);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(signUp);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(signIn);
            panel1.Controls.Add(passwordTextBox);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(usernameTxtBox);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(162, 67);
            panel1.Name = "panel1";
            panel1.Size = new Size(1493, 966);
            panel1.TabIndex = 1;
            // 
            // signUp
            // 
            signUp.AutoSize = true;
            signUp.Cursor = Cursors.Hand;
            signUp.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signUp.ForeColor = Color.FromArgb(236, 19, 19);
            signUp.Location = new Point(834, 847);
            signUp.Name = "signUp";
            signUp.Size = new Size(167, 40);
            signUp.TabIndex = 8;
            signUp.Text = "Create one";
            signUp.Click += this.signUp_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(166, 166, 166);
            label4.Location = new Point(497, 847);
            label4.Name = "label4";
            label4.Size = new Size(342, 40);
            label4.TabIndex = 7;
            label4.Text = "Don't have an account?";
            // 
            // signIn
            // 
            signIn.BackColor = Color.FromArgb(236, 19, 19);
            signIn.Cursor = Cursors.Hand;
            signIn.FlatStyle = FlatStyle.Flat;
            signIn.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signIn.ForeColor = Color.White;
            signIn.Location = new Point(457, 746);
            signIn.Name = "signIn";
            signIn.Size = new Size(606, 78);
            signIn.TabIndex = 6;
            signIn.Text = "Sign In";
            signIn.UseVisualStyleBackColor = false;
            signIn.Click += this.signIn_Click;
            // 
            // passwordTextBox
            // 
            passwordTextBox.BackColor = Color.FromArgb(18, 18, 18);
            passwordTextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordTextBox.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            passwordTextBox.ForeColor = Color.FromArgb(166, 166, 166);
            passwordTextBox.Location = new Point(438, 630);
            passwordTextBox.Multiline = true;
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.PlaceholderText = "Enter your password";
            passwordTextBox.Size = new Size(649, 78);
            passwordTextBox.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(438, 578);
            label3.Name = "label3";
            label3.Size = new Size(151, 40);
            label3.TabIndex = 4;
            label3.Text = "password";
            // 
            // usernameTxtBox
            // 
            usernameTxtBox.BackColor = Color.FromArgb(18, 18, 18);
            usernameTxtBox.BorderStyle = BorderStyle.FixedSingle;
            usernameTxtBox.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            usernameTxtBox.ForeColor = Color.FromArgb(166, 166, 166);
            usernameTxtBox.Location = new Point(438, 474);
            usernameTxtBox.Multiline = true;
            usernameTxtBox.Name = "usernameTxtBox";
            usernameTxtBox.PlaceholderText = "Enter your username";
            usernameTxtBox.Size = new Size(649, 78);
            usernameTxtBox.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(438, 422);
            label2.Name = "label2";
            label2.Size = new Size(158, 40);
            label2.TabIndex = 2;
            label2.Text = "Username";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(614, 21);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(280, 268);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.Black;
            ClientSize = new Size(1820, 1167);
            Controls.Add(panel1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += this.Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private PictureBox pictureBox1;
        private TextBox usernameTxtBox;
        private Label label2;
        private TextBox passwordTextBox;
        private Label label3;
        private Button signIn;
        private Label signUp;
        private Label label4;
    }
}
