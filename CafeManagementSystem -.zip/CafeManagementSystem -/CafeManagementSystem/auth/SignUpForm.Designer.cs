﻿namespace CafeManagementSystem.auth
{
    partial class SignUpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            login = new Label();
            textBox2 = new TextBox();
            label6 = new Label();
            textBox1 = new TextBox();
            label5 = new Label();
            label4 = new Label();
            SignUp = new Button();
            passwordTextBox = new TextBox();
            label3 = new Label();
            usernameTxtBox = new TextBox();
            label2 = new Label();
            label1 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(23, 23, 23);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(login);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(SignUp);
            panel1.Controls.Add(passwordTextBox);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(usernameTxtBox);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(164, 100);
            panel1.Name = "panel1";
            panel1.Size = new Size(1493, 1280);
            panel1.TabIndex = 2;
            // 
            // login
            // 
            login.AutoSize = true;
            login.Cursor = Cursors.Hand;
            login.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            login.ForeColor = Color.FromArgb(236, 19, 19);
            login.Location = new Point(876, 1179);
            login.Name = "login";
            login.Size = new Size(99, 40);
            login.TabIndex = 13;
            login.Text = "Login";
            login.Click += login_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(18, 18, 18);
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.ForeColor = Color.FromArgb(166, 166, 166);
            textBox2.Location = new Point(438, 913);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Enter your Address";
            textBox2.Size = new Size(649, 132);
            textBox2.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(438, 861);
            label6.Name = "label6";
            label6.Size = new Size(132, 40);
            label6.TabIndex = 11;
            label6.Text = "Address";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(18, 18, 18);
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.ForeColor = Color.FromArgb(166, 166, 166);
            textBox1.Location = new Point(438, 624);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Enter your Email";
            textBox1.Size = new Size(649, 78);
            textBox1.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(438, 572);
            label5.Name = "label5";
            label5.Size = new Size(99, 40);
            label5.TabIndex = 9;
            label5.Text = "Email";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(166, 166, 166);
            label4.Location = new Point(492, 1179);
            label4.Name = "label4";
            label4.Size = new Size(378, 40);
            label4.TabIndex = 7;
            label4.Text = "Already have an account?";
            // 
            // SignUp
            // 
            SignUp.BackColor = Color.FromArgb(236, 19, 19);
            SignUp.Cursor = Cursors.Hand;
            SignUp.FlatStyle = FlatStyle.Flat;
            SignUp.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SignUp.ForeColor = Color.White;
            SignUp.Location = new Point(452, 1078);
            SignUp.Name = "SignUp";
            SignUp.Size = new Size(606, 78);
            SignUp.TabIndex = 6;
            SignUp.Text = "Sign In";
            SignUp.UseVisualStyleBackColor = false;
            SignUp.Click += SignUp_Click;
            // 
            // passwordTextBox
            // 
            passwordTextBox.BackColor = Color.FromArgb(18, 18, 18);
            passwordTextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordTextBox.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            passwordTextBox.ForeColor = Color.FromArgb(166, 166, 166);
            passwordTextBox.Location = new Point(438, 771);
            passwordTextBox.Multiline = true;
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.PlaceholderText = "Enter your password";
            passwordTextBox.Size = new Size(649, 78);
            passwordTextBox.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(438, 719);
            label3.Name = "label3";
            label3.Size = new Size(151, 40);
            label3.TabIndex = 4;
            label3.Text = "password";
            // 
            // usernameTxtBox
            // 
            usernameTxtBox.BackColor = Color.FromArgb(18, 18, 18);
            usernameTxtBox.BorderStyle = BorderStyle.FixedSingle;
            usernameTxtBox.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            usernameTxtBox.ForeColor = Color.FromArgb(166, 166, 166);
            usernameTxtBox.Location = new Point(438, 474);
            usernameTxtBox.Multiline = true;
            usernameTxtBox.Name = "usernameTxtBox";
            usernameTxtBox.PlaceholderText = "Enter your username";
            usernameTxtBox.Size = new Size(649, 78);
            usernameTxtBox.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(438, 422);
            label2.Name = "label2";
            label2.Size = new Size(158, 40);
            label2.TabIndex = 2;
            label2.Text = "Username";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(552, 304);
            label1.Name = "label1";
            label1.Size = new Size(427, 61);
            label1.TabIndex = 0;
            label1.Text = "User Registration";
            // 
            // SignUpForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1820, 1465);
            Controls.Add(panel1);
            Name = "SignUpForm";
            Text = "SignUpForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label4;
        private Button SignUp;
        private TextBox passwordTextBox;
        private Label label3;
        private TextBox usernameTxtBox;
        private Label label2;
        private Label label1;
        private TextBox textBox2;
        private Label label6;
        private TextBox textBox1;
        private Label label5;
        private Label login;
    }
}