﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CafeManagementSystem.auth
{
    public partial class SignUpForm : Form
    {
        static string conStr = "Data Source=MAC4C34\\SQLEXPRESS;Initial Catalog=CafeManagementSystem;Integrated Security=True";
        static SqlConnection con = new SqlConnection(conStr);
        public SignUpForm()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, EventArgs e)
        {
            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Hide();
        }

        private void SignUp_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string q = "AddCustomer";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Username", usernameTxtBox.Text.Trim());
                cmd.Parameters.AddWithValue("@Password", passwordTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", textBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@Role", "Customer");
                cmd.Parameters.AddWithValue("@Address", textBox2.Text.Trim());
                cmd.ExecuteNonQuery();
                MessageBox.Show("Account created successfully!");
                usernameTxtBox.Clear();
                passwordTextBox.Clear();
                textBox1.Clear();
                textBox2.Clear();
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
