﻿namespace CafeManagementSystem.UserFlow
{
    partial class UserDashBoardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            MenuManageMentBtn = new Button();
            button5 = new Button();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(31, 31, 31);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(MenuManageMentBtn);
            panel1.Location = new Point(68, 267);
            panel1.Name = "panel1";
            panel1.Size = new Size(1715, 1114);
            panel1.TabIndex = 11;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(38, 38, 38);
            button3.Cursor = Cursors.Hand;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Times New Roman", 22.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(641, 619);
            button3.Name = "button3";
            button3.Size = new Size(410, 365);
            button3.TabIndex = 10;
            button3.Text = "Profile";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(38, 38, 38);
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Times New Roman", 22.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(1203, 167);
            button2.Name = "button2";
            button2.Size = new Size(410, 365);
            button2.TabIndex = 9;
            button2.Text = "Order Details";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(38, 38, 38);
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Times New Roman", 22.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(641, 167);
            button1.Name = "button1";
            button1.Size = new Size(410, 365);
            button1.TabIndex = 8;
            button1.Text = "View Cart";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // MenuManageMentBtn
            // 
            MenuManageMentBtn.BackColor = Color.FromArgb(38, 38, 38);
            MenuManageMentBtn.Cursor = Cursors.Hand;
            MenuManageMentBtn.FlatStyle = FlatStyle.Flat;
            MenuManageMentBtn.Font = new Font("Times New Roman", 22.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            MenuManageMentBtn.ForeColor = Color.White;
            MenuManageMentBtn.Location = new Point(90, 167);
            MenuManageMentBtn.Name = "MenuManageMentBtn";
            MenuManageMentBtn.Size = new Size(410, 365);
            MenuManageMentBtn.TabIndex = 7;
            MenuManageMentBtn.Text = "Cafe Menu";
            MenuManageMentBtn.UseVisualStyleBackColor = false;
            MenuManageMentBtn.Click += MenuManageMentBtn_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(18, 18, 18);
            button5.Cursor = Cursors.Hand;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Times New Roman", 13.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.Location = new Point(1323, 74);
            button5.Name = "button5";
            button5.Size = new Size(347, 101);
            button5.TabIndex = 13;
            button5.Text = "Sign Out";
            button5.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Haseebullah_Pitafi;
            pictureBox2.Location = new Point(68, 36);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(246, 196);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 12;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(350, 95);
            label1.Name = "label1";
            label1.Size = new Size(674, 61);
            label1.TabIndex = 10;
            label1.Text = "Welcome, Haseebullah Khan";
            // 
            // UserDashBoardForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1850, 1416);
            Controls.Add(panel1);
            Controls.Add(button5);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Name = "UserDashBoardForm";
            Text = "UserDashBoardForm";
            Load += UserDashBoardForm_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button button3;
        private Button button2;
        private Button button1;
        private Button MenuManageMentBtn;
        private Button button5;
        private PictureBox pictureBox2;
        private Label label1;
    }
}