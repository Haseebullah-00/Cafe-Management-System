﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CafeManagementSystem.UserFlow.Profile
{
    public partial class ProfileForm : Form
    {
        static string conStr =
            "Data Source=MAC4C34\\SQLEXPRESS;Initial Catalog=CafeManagementSystem;Integrated Security=True";

        int loginId;

        public ProfileForm(int id)
        {
            InitializeComponent();
            loginId = id;
        }


        private void LoadProfile()
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = @"
                SELECT L.Username, L.Password, C.Email, C.Address
                FROM Login L
                INNER JOIN Customer C ON L.Id = C.CId
                WHERE L.Id = @Id";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@Id", loginId);

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    textBox4.Text = dr["Username"].ToString();
                    textBox3.Text = dr["Password"].ToString();
                    textBox1.Text = dr["Email"].ToString();
                    textBox2.Text = dr["Address"].ToString();
                }

                dr.Close();
            }
        }

        // 🔷 UPDATE PROFILE
        private void UpdateProfile()
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = @"
                UPDATE Login
                SET Username = @Username,
                    Password = @Password
                WHERE Id = @Id;

                UPDATE Customer
                SET Email = @Email,
                    Address = @Address
                WHERE CId = @Id;
                ";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@Id", loginId);
                cmd.Parameters.AddWithValue("@Username", textBox4.Text);
                cmd.Parameters.AddWithValue("@Password", textBox3.Text);
                cmd.Parameters.AddWithValue("@Email", textBox1.Text);
                cmd.Parameters.AddWithValue("@Address", textBox2.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Profile updated successfully!");
            }
        }


        


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            LoadProfile();
        }


        private void SignUp_Click(object sender, EventArgs e)
        {
            UpdateProfile();
        }

        private void ProfileForm_Load_1(object sender, EventArgs e)
        {
            LoadProfile();
        }
    }
}