﻿namespace CafeManagementSystem.UserFlow.Profile
{
    partial class ProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            textBox2 = new TextBox();
            label6 = new Label();
            textBox1 = new TextBox();
            label5 = new Label();
            SignUp = new Button();
            pictureBox1 = new PictureBox();
            textBox3 = new TextBox();
            label8 = new Label();
            textBox4 = new TextBox();
            label9 = new Label();
            label10 = new Label();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(23, 23, 23);
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(textBox2);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(textBox1);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(SignUp);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(textBox3);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(textBox4);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(label10);
            panel2.Location = new Point(120, 96);
            panel2.Name = "panel2";
            panel2.Size = new Size(1493, 1256);
            panel2.TabIndex = 8;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(18, 18, 18);
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.ForeColor = Color.FromArgb(166, 166, 166);
            textBox2.Location = new Point(438, 913);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Enter your Address";
            textBox2.Size = new Size(649, 132);
            textBox2.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(438, 861);
            label6.Name = "label6";
            label6.Size = new Size(132, 40);
            label6.TabIndex = 11;
            label6.Text = "Address";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(18, 18, 18);
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.ForeColor = Color.FromArgb(166, 166, 166);
            textBox1.Location = new Point(438, 624);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Enter your Email";
            textBox1.Size = new Size(649, 78);
            textBox1.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(438, 572);
            label5.Name = "label5";
            label5.Size = new Size(99, 40);
            label5.TabIndex = 9;
            label5.Text = "Email";
            // 
            // SignUp
            // 
            SignUp.BackColor = Color.FromArgb(236, 19, 19);
            SignUp.Cursor = Cursors.Hand;
            SignUp.FlatStyle = FlatStyle.Flat;
            SignUp.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SignUp.ForeColor = Color.White;
            SignUp.Location = new Point(452, 1078);
            SignUp.Name = "SignUp";
            SignUp.Size = new Size(606, 78);
            SignUp.TabIndex = 6;
            SignUp.Text = "Edit Profile";
            SignUp.UseVisualStyleBackColor = false;
            SignUp.Click += SignUp_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Haseebullah_Pitafi;
            pictureBox1.Location = new Point(618, 110);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(280, 268);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(18, 18, 18);
            textBox3.BorderStyle = BorderStyle.FixedSingle;
            textBox3.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.ForeColor = Color.FromArgb(166, 166, 166);
            textBox3.Location = new Point(438, 771);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Enter your password";
            textBox3.Size = new Size(649, 78);
            textBox3.TabIndex = 5;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(438, 719);
            label8.Name = "label8";
            label8.Size = new Size(151, 40);
            label8.TabIndex = 4;
            label8.Text = "password";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(18, 18, 18);
            textBox4.BorderStyle = BorderStyle.FixedSingle;
            textBox4.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.ForeColor = Color.FromArgb(166, 166, 166);
            textBox4.Location = new Point(438, 474);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.PlaceholderText = "Enter your username";
            textBox4.Size = new Size(649, 78);
            textBox4.TabIndex = 3;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(438, 422);
            label9.Name = "label9";
            label9.Size = new Size(158, 40);
            label9.TabIndex = 2;
            label9.Text = "Username";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(667, 22);
            label10.Name = "label10";
            label10.Size = new Size(181, 61);
            label10.TabIndex = 0;
            label10.Text = "Profile";
            // 
            // ProfileForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1833, 1400);
            Controls.Add(panel2);
            Name = "ProfileForm";
            Text = "ProfileForm";
            Load += ProfileForm_Load_1;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private TextBox textBox2;
        private Label label6;
        private TextBox textBox1;
        private Label label5;
        private Button SignUp;
        private PictureBox pictureBox1;
        private TextBox textBox3;
        private Label label8;
        private TextBox textBox4;
        private Label label9;
        private Label label10;
    }
}