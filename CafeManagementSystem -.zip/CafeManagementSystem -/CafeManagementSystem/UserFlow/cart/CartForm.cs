﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CafeManagementSystem.UserFlow.cart
{
    public partial class CartForm : Form
    {
        static string conStr =
            "Data Source=MAC4C34\\SQLEXPRESS;Initial Catalog=CafeManagementSystem;Integrated Security=True";

        int logId;

        public CartForm(int loginId)
        {
            InitializeComponent();
            logId = loginId;
            this.Load += CartForm_Load;
            dataGridView1.CellEndEdit += dataGridView1_CellEndEdit;
        }

        private void CartForm_Load(object sender, EventArgs e)
        {
            LoadCart();
            LoadTotal();
        }

        private void LoadCart()
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = @"
SELECT 
    c.CartId,
    p.ProductName,
    c.Quantity,
    c.UnitPrice,
    (c.Quantity * c.UnitPrice) AS Total
FROM UserCart c
INNER JOIN Product p ON c.ProductId = p.ProductId
WHERE c.LoginId = @LoginId";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@LoginId", logId);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);


                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dt;

                MapColumns();


                if (dataGridView1.Columns.Contains("CartId"))
                    dataGridView1.Columns["CartId"].Visible = false;


                if (dataGridView1.Columns.Contains("Quantity"))
                    dataGridView1.Columns["Quantity"].ReadOnly = false;
            }
        }
        private void MapColumns()
        {
            dataGridView1.Columns["CartId"].DataPropertyName = "CartId";
            dataGridView1.Columns["ProductName"].DataPropertyName = "ProductName";
            dataGridView1.Columns["Quantity"].DataPropertyName = "Quantity";
            dataGridView1.Columns["UnitPrice"].DataPropertyName = "UnitPrice";
            dataGridView1.Columns["Total"].DataPropertyName = "Total";
        }


        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "Quantity")
            {
                int cartId = Convert.ToInt32(
                    dataGridView1.Rows[e.RowIndex].Cells["CartId"].Value
                );

                int quantity = Convert.ToInt32(
                    dataGridView1.Rows[e.RowIndex].Cells["Quantity"].Value
                );

                UpdateQuantity(cartId, quantity);
            }
        }

        private void UpdateQuantity(int cartId, int quantity)
        {
            if (quantity <= 0)
            {
                RemoveItem(cartId);
                return;
            }

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = @"
UPDATE UserCart
SET Quantity = @Quantity
WHERE CartId = @CartId AND LoginId = @LoginId";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@Quantity", quantity);
                cmd.Parameters.AddWithValue("@CartId", cartId);
                cmd.Parameters.AddWithValue("@LoginId", logId);

                cmd.ExecuteNonQuery();
            }

            LoadCart();
            LoadTotal();
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (dataGridView1.Columns[e.ColumnIndex].Name == "RemoveBtn")
            {
                int cartId = Convert.ToInt32(
                    dataGridView1.Rows[e.RowIndex].Cells["CartId"].Value
                );

                DialogResult result = MessageBox.Show(
                    "Remove this item?",
                    "Confirm",
                    MessageBoxButtons.YesNo
                );

                if (result == DialogResult.Yes)
                {
                    RemoveItem(cartId);
                }
            }
        }

        private void RemoveItem(int cartId)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = "DELETE FROM UserCart WHERE CartId=@CartId AND LoginId=@LoginId";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@CartId", cartId);
                cmd.Parameters.AddWithValue("@LoginId", logId);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Item removed!");

            LoadCart();
            LoadTotal();
        }


        private void LoadTotal()
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = "SELECT SUM(Quantity * UnitPrice) FROM UserCart WHERE LoginId=@LoginId";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@LoginId", logId);

                object result = cmd.ExecuteScalar();

                if (result == DBNull.Value || result == null)
                    totalLbl.Text = " 0";
                else
                    totalLbl.Text = result.ToString();
            }
        }

        private void checkout_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("PlaceOrder", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                  
                    cmd.Parameters.AddWithValue("@LoginId", logId);

                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        string msg = dr["Message"].ToString();

                        if (msg.StartsWith("ERROR"))
                        {
                            MessageBox.Show(msg);
                        }
                        else
                        {
                            MessageBox.Show(
                                msg +
                                "\nOrder ID: " + dr["OrderId"] +
                                "\nTotal: " + dr["TotalAmount"]
                            );
                        }
                    }

                    dr.Close();
                }

                // refresh UI after checkout
                LoadCart();
                LoadTotal();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}