﻿namespace CafeManagementSystem.UserFlow.cart
{
    partial class CartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            panel1 = new Panel();
            totalLbl = new Label();
            label2 = new Label();
            dataGridView1 = new DataGridView();
            CartId = new DataGridViewTextBoxColumn();
            ProductName = new DataGridViewTextBoxColumn();
            Quantity = new DataGridViewTextBoxColumn();
            UnitPrice = new DataGridViewTextBoxColumn();
            Total = new DataGridViewTextBoxColumn();
            RemoveBtn = new DataGridViewButtonColumn();
            checkout = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(691, 24);
            label1.Name = "label1";
            label1.Size = new Size(134, 61);
            label1.TabIndex = 11;
            label1.Text = "Cart";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(23, 23, 23);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(checkout);
            panel1.Controls.Add(totalLbl);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(dataGridView1);
            panel1.Location = new Point(43, 132);
            panel1.Name = "panel1";
            panel1.Size = new Size(1740, 1221);
            panel1.TabIndex = 12;
            // 
            // totalLbl
            // 
            totalLbl.AutoSize = true;
            totalLbl.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            totalLbl.ForeColor = Color.White;
            totalLbl.Location = new Point(426, 856);
            totalLbl.Name = "totalLbl";
            totalLbl.Size = new Size(0, 40);
            totalLbl.TabIndex = 24;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(113, 839);
            label2.Name = "label2";
            label2.Size = new Size(255, 61);
            label2.TabIndex = 2;
            label2.Text = "Total Bill:";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { CartId, ProductName, Quantity, UnitPrice, Total, RemoveBtn });
            dataGridView1.Location = new Point(244, 143);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.Size = new Size(1082, 560);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // CartId
            // 
            CartId.HeaderText = "CartId";
            CartId.MinimumWidth = 10;
            CartId.Name = "CartId";
            CartId.Visible = false;
            CartId.Width = 200;
            // 
            // ProductName
            // 
            ProductName.HeaderText = "ProductName";
            ProductName.MinimumWidth = 10;
            ProductName.Name = "ProductName";
            ProductName.Width = 200;
            // 
            // Quantity
            // 
            Quantity.HeaderText = "Quantity";
            Quantity.MinimumWidth = 10;
            Quantity.Name = "Quantity";
            Quantity.Width = 200;
            // 
            // UnitPrice
            // 
            UnitPrice.HeaderText = "UnitPrice";
            UnitPrice.MinimumWidth = 10;
            UnitPrice.Name = "UnitPrice";
            UnitPrice.Width = 200;
            // 
            // Total
            // 
            Total.HeaderText = "Total";
            Total.MinimumWidth = 10;
            Total.Name = "Total";
            Total.Width = 200;
            // 
            // RemoveBtn
            // 
            RemoveBtn.HeaderText = "Remove";
            RemoveBtn.MinimumWidth = 10;
            RemoveBtn.Name = "RemoveBtn";
            RemoveBtn.Text = "Remove";
            RemoveBtn.UseColumnTextForButtonValue = true;
            RemoveBtn.Width = 200;
            // 
            // checkout
            // 
            checkout.BackColor = Color.FromArgb(236, 19, 19);
            checkout.Cursor = Cursors.Hand;
            checkout.FlatStyle = FlatStyle.Flat;
            checkout.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkout.ForeColor = Color.White;
            checkout.Location = new Point(566, 978);
            checkout.Name = "checkout";
            checkout.Size = new Size(271, 78);
            checkout.TabIndex = 25;
            checkout.Text = "Checkout";
            checkout.UseVisualStyleBackColor = false;
            checkout.Click += checkout_Click;
            // 
            // CartForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1826, 1417);
            Controls.Add(label1);
            Controls.Add(panel1);
            Name = "CartForm";
            Text = "CartForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn CartId;
        private DataGridViewTextBoxColumn ProductName;
        private DataGridViewTextBoxColumn Quantity;
        private DataGridViewTextBoxColumn UnitPrice;
        private DataGridViewTextBoxColumn Total;
        private DataGridViewButtonColumn RemoveBtn;
        private Label label2;
        private Label totalLbl;
        private Button checkout;
    }
}