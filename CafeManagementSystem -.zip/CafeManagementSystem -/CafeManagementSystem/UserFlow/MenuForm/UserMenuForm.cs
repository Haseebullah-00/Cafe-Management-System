﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CafeManagementSystem.UserFlow.MenuForm
{
    public partial class UserMenuForm : Form
    {
        static string conStr = "Data Source=MAC4C34\\SQLEXPRESS;Initial Catalog=CafeManagementSystem;Integrated Security=True";
        static SqlConnection con = new SqlConnection(conStr);
        static int logId;
        public UserMenuForm(int loginId)
        {
            InitializeComponent();
            logId = loginId;
        }

        private void UserMenuForm_Load(object sender, EventArgs e)
        {
            LoadProducts();
        }
        private void LoadProducts()
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = @"SELECT ProductId, ProductName, Description, Category, Price 
                     FROM Product 
                     WHERE IsAvailable = 1";

                SqlDataAdapter da = new SqlDataAdapter(q, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dt;

                MapColumns();
            }
        }
        private void MapColumns()
        {
            dataGridView1.Columns["productId"].DataPropertyName = "ProductId";
            dataGridView1.Columns["pName"].DataPropertyName = "ProductName";
            dataGridView1.Columns["description"].DataPropertyName = "Description";
            dataGridView1.Columns["category"].DataPropertyName = "Category";
            dataGridView1.Columns["price"].DataPropertyName = "Price";
        }

        private void AddToCart(int productId, int quantity)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("AddUserCartItem", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@LoginId", logId);
                    cmd.Parameters.AddWithValue("@ProductId", productId);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);

                    SqlDataReader dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        MessageBox.Show(dr["Message"].ToString());
                    }

                    dr.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (dataGridView1.Columns[e.ColumnIndex].Name == "addBtn")
            {
                int productId = Convert.ToInt32(
                    dataGridView1.Rows[e.RowIndex].Cells["productId"].Value
                );

                int quantity = 1;

                if (dataGridView1.Rows[e.RowIndex].Cells["qty"].Value != null)
                {
                    quantity = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["qty"].Value);
                }

                AddToCart(productId, quantity);
            }
        }
       
        private void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                row.Cells["qty"].Value = 1;
            }
        }
    }
}
