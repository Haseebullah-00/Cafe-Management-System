﻿namespace CafeManagementSystem.UserFlow.MenuForm
{
    partial class UserMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            panel1 = new Panel();
            pName = new DataGridViewTextBoxColumn();
            description = new DataGridViewTextBoxColumn();
            Category = new DataGridViewTextBoxColumn();
            price = new DataGridViewTextBoxColumn();
            qty = new DataGridViewTextBoxColumn();
            addBtn = new DataGridViewButtonColumn();
            productId = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(38, 38, 38);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { pName, description, Category, price, qty, addBtn, productId });
            dataGridView1.GridColor = SystemColors.ControlDark;
            dataGridView1.Location = new Point(76, 298);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.Size = new Size(1592, 641);
            dataGridView1.TabIndex = 7;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(23, 23, 23);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(dataGridView1);
            panel1.Location = new Point(106, 137);
            panel1.Name = "panel1";
            panel1.Size = new Size(1740, 996);
            panel1.TabIndex = 8;
            // 
            // pName
            // 
            pName.HeaderText = "ProductName";
            pName.MinimumWidth = 10;
            pName.Name = "pName";
            pName.Width = 200;
            // 
            // description
            // 
            description.HeaderText = "Description";
            description.MinimumWidth = 10;
            description.Name = "description";
            description.Width = 200;
            // 
            // Category
            // 
            Category.HeaderText = "Category";
            Category.MinimumWidth = 10;
            Category.Name = "Category";
            Category.Width = 200;
            // 
            // price
            // 
            price.HeaderText = "Price";
            price.MinimumWidth = 10;
            price.Name = "price";
            price.Width = 200;
            // 
            // qty
            // 
            qty.HeaderText = "Quantity";
            qty.MinimumWidth = 10;
            qty.Name = "qty";
            qty.Width = 200;
            // 
            // addBtn
            // 
            addBtn.HeaderText = "Add";
            addBtn.MinimumWidth = 10;
            addBtn.Name = "addBtn";
            addBtn.Text = "Add";
            addBtn.UseColumnTextForButtonValue = true;
            addBtn.Width = 200;
            // 
            // productId
            // 
            productId.HeaderText = "Pid";
            productId.MinimumWidth = 10;
            productId.Name = "productId";
            productId.Visible = false;
            productId.Width = 200;
            // 
            // UserMenuForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(2057, 1193);
            Controls.Add(panel1);
            Name = "UserMenuForm";
            Text = "UserMenuForm";
            Load += UserMenuForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private Panel panel1;
        private DataGridViewTextBoxColumn pName;
        private DataGridViewTextBoxColumn description;
        private DataGridViewTextBoxColumn Category;
        private DataGridViewTextBoxColumn price;
        private DataGridViewTextBoxColumn qty;
        private DataGridViewButtonColumn addBtn;
        private DataGridViewTextBoxColumn productId;
    }
}