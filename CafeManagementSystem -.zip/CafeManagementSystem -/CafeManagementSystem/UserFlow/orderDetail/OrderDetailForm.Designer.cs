﻿namespace CafeManagementSystem.UserFlow.orderDetail
{
    partial class OrderDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblOrderId = new Label();
            lblStatus = new Label();
            lblPayment = new Label();
            lblTotal = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            label1 = new Label();
            discountlbl = new Label();
            finallbl = new Label();
            SuspendLayout();
            // 
            // lblOrderId
            // 
            lblOrderId.AutoSize = true;
            lblOrderId.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblOrderId.ForeColor = Color.White;
            lblOrderId.Location = new Point(183, 59);
            lblOrderId.Name = "lblOrderId";
            lblOrderId.Size = new Size(100, 40);
            lblOrderId.TabIndex = 16;
            lblOrderId.Text = "Name";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblStatus.ForeColor = Color.White;
            lblStatus.Location = new Point(636, 59);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(100, 40);
            lblStatus.TabIndex = 17;
            lblStatus.Text = "Name";
            // 
            // lblPayment
            // 
            lblPayment.AutoSize = true;
            lblPayment.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPayment.ForeColor = Color.White;
            lblPayment.Location = new Point(183, 175);
            lblPayment.Name = "lblPayment";
            lblPayment.Size = new Size(100, 40);
            lblPayment.TabIndex = 18;
            lblPayment.Text = "Name";
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTotal.ForeColor = Color.White;
            lblTotal.Location = new Point(636, 161);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(100, 40);
            lblTotal.TabIndex = 19;
            lblTotal.Text = "Name";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AutoScroll = true;
            flowLayoutPanel1.BackColor = Color.FromArgb(23, 23, 23);
            flowLayoutPanel1.Location = new Point(70, 303);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(1585, 474);
            flowLayoutPanel1.TabIndex = 20;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(759, 0);
            label1.Name = "label1";
            label1.Size = new Size(78, 32);
            label1.TabIndex = 21;
            label1.Text = "label1";
            // 
            // discountlbl
            // 
            discountlbl.AutoSize = true;
            discountlbl.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            discountlbl.ForeColor = Color.White;
            discountlbl.Location = new Point(935, 59);
            discountlbl.Name = "discountlbl";
            discountlbl.Size = new Size(100, 40);
            discountlbl.TabIndex = 22;
            discountlbl.Text = "Name";
            // 
            // finallbl
            // 
            finallbl.AutoSize = true;
            finallbl.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            finallbl.ForeColor = Color.White;
            finallbl.Location = new Point(935, 161);
            finallbl.Name = "finallbl";
            finallbl.Size = new Size(100, 40);
            finallbl.TabIndex = 23;
            finallbl.Text = "Name";
            // 
            // OrderDetailForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1709, 855);
            Controls.Add(finallbl);
            Controls.Add(discountlbl);
            Controls.Add(label1);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(lblTotal);
            Controls.Add(lblPayment);
            Controls.Add(lblStatus);
            Controls.Add(lblOrderId);
            Name = "OrderDetailForm";
            Text = "OrderDetailForm";
            Load += OrderDetailForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblOrderId;
        private Label lblStatus;
        private Label lblPayment;
        private Label lblTotal;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label label1;
        private Label discountlbl;
        private Label finallbl;
    }
}