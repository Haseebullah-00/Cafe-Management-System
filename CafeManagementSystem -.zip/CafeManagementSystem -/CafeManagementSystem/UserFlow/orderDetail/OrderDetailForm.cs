﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CafeManagementSystem.UserFlow.orderDetail
{
    public partial class OrderDetailForm : Form
    {
        static string conStr =
            "Data Source=MAC4C34\\SQLEXPRESS;Initial Catalog=CafeManagementSystem;Integrated Security=True";

        int loginId;

        public OrderDetailForm(int loginId)
        {
            InitializeComponent();
            this.loginId = loginId;
        }

        private void OrderDetailForm_Load(object sender, EventArgs e)
        {
            int orderId = GetLatestOrderId();

            if (orderId == 0)
            {
                MessageBox.Show("No order found!");
                return;
            }

            LoadOrderInfo(orderId);
            LoadOrderItems(orderId);
        }

        // 🔷 GET LATEST ORDER OF USER
        private int GetLatestOrderId()
        {
            int orderId = 0;

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = @"
                SELECT TOP 1 OrderId
                FROM Orders
                WHERE CustomerId = @LoginId
                ORDER BY OrderId DESC";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@LoginId", loginId);

                object result = cmd.ExecuteScalar();

                if (result != null)
                    orderId = Convert.ToInt32(result);
            }

            return orderId;
        }


        private void LoadOrderInfo(int orderId)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = @"
        SELECT OrderDate, TotalAmount, Status, PaymentStatus
        FROM Orders
        WHERE OrderId = @OrderId AND CustomerId = @LoginId";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@OrderId", orderId);
                cmd.Parameters.AddWithValue("@LoginId", loginId);

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    lblOrderId.Text = "Order ID: " + orderId;
                    lblStatus.Text = "Status: " + dr["Status"].ToString();
                    lblPayment.Text = "Payment: " + dr["PaymentStatus"].ToString();

                    decimal totalAmount = Convert.ToDecimal(dr["TotalAmount"]);

                    dr.Close(); 

                    
                    decimal discount = 0;
                    decimal finalAmount = 0;

                    using (SqlConnection con2 = new SqlConnection(conStr))
                    {
                        con2.Open();

                        SqlCommand cmd2 = new SqlCommand("ApplyDiscount", con2);
                        cmd2.CommandType = System.Data.CommandType.StoredProcedure;

                        cmd2.Parameters.AddWithValue("@OrderId", orderId);

                        SqlParameter p1 = new SqlParameter("@DiscountPercent", System.Data.SqlDbType.Decimal);
                        p1.Direction = System.Data.ParameterDirection.Output;
                        p1.Precision = 5;
                        p1.Scale = 2;

                        SqlParameter p2 = new SqlParameter("@FinalAmount", System.Data.SqlDbType.Decimal);
                        p2.Direction = System.Data.ParameterDirection.Output;
                        p2.Precision = 10;
                        p2.Scale = 2;

                        cmd2.Parameters.Add(p1);
                        cmd2.Parameters.Add(p2);

                        cmd2.ExecuteNonQuery();

                        discount = Convert.ToDecimal(p1.Value);
                        finalAmount = Convert.ToDecimal(p2.Value);
                    }

               
                    lblTotal.Text = "Total: " + totalAmount;
                    discountlbl.Text = "Discount: " + discount + "%";
                    finallbl.Text = "Final: " + finalAmount;
                }
                else
                {
                    dr.Close();
                }
            }
        }


        private void LoadOrderItems(int orderId)
        {
            flowLayoutPanel1.Controls.Clear();

            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = @"
                SELECT 
                    p.ProductName,
                    od.Quantity,
                    od.UnitPrice,
                    (od.Quantity * od.UnitPrice) AS Total
                FROM OrderDetails od
                INNER JOIN Product p ON od.ProductId = p.ProductId
                INNER JOIN Orders o ON o.OrderId = od.OrderId
                WHERE od.OrderId = @OrderId AND o.CustomerId = @LoginId";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@OrderId", orderId);
                cmd.Parameters.AddWithValue("@LoginId", loginId);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Panel row = new Panel();
                    row.Width = flowLayoutPanel1.Width - 25;
                    row.Height = 70;
                    row.BackColor = Color.Black;
                    row.Margin = new Padding(5);

                    int topPadding = 25;

                    
                    Label name = new Label();
                    name.Text = dr["ProductName"].ToString();
                    name.ForeColor = Color.White;
                    name.Width = 150;
                    name.Left = 10;
                    name.Top = topPadding;

                 
                    Label qty = new Label();
                    qty.Text = "Qty: " + dr["Quantity"].ToString();
                    qty.ForeColor = Color.White;
                    qty.Left = 180;
                    qty.Top = topPadding;

                   
                    Label price = new Label();
                    price.Text = "Price: " + dr["UnitPrice"].ToString();
                    price.ForeColor = Color.White;
                    price.Left = 300;
                    price.Top = topPadding;

                  
                    Label total = new Label();
                    total.Text = "Total: " + dr["Total"].ToString();
                    total.ForeColor = Color.White;
                    total.Left = 430;
                    total.Top = topPadding;

                    
                    Panel line = new Panel();
                    line.Height = 1;
                    line.Dock = DockStyle.Bottom;
                    line.BackColor = Color.White;

                    row.Controls.Add(name);
                    row.Controls.Add(qty);
                    row.Controls.Add(price);
                    row.Controls.Add(total);
                    row.Controls.Add(line);

                    flowLayoutPanel1.Controls.Add(row);
                }

                dr.Close();
            }
        }
    }
}