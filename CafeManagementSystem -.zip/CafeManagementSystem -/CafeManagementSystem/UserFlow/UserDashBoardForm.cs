﻿using CafeManagementSystem.UserFlow.cart;
using CafeManagementSystem.UserFlow.MenuForm;
using CafeManagementSystem.UserFlow.orderDetail;
using CafeManagementSystem.UserFlow.Profile;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeManagementSystem.UserFlow
{
    public partial class UserDashBoardForm : Form
    {
        static int id;
        static string name;
        public UserDashBoardForm(int _id, string _name)
        {
            InitializeComponent();
            id = _id;
            name = _name;
        }

        private void MenuManageMentBtn_Click(object sender, EventArgs e)
        {
            UserMenuForm userMenuForm = new UserMenuForm(id);
            userMenuForm.Show();
            this.Hide();




        }

        private void UserDashBoardForm_Load(object sender, EventArgs e)
        {
            label1.Text = $"Welcome,{name}";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CartForm cartForm = new CartForm(id);
            cartForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OrderDetailForm orderDetailForm = new OrderDetailForm(id);
            orderDetailForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ProfileForm profileForm = new ProfileForm(id);
            profileForm.Show();
            this.Hide();
        }
    }
}
