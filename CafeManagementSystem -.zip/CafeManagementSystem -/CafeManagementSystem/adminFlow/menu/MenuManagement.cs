﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CafeManagementSystem.adminFlow.menu
{
    public partial class MenuManagement : Form
    {
        static string conStr = "Data Source=MAC4C34\\SQLEXPRESS;Initial Catalog=CafeManagementSystem;Integrated Security=True";
        static SqlConnection con = new SqlConnection(conStr);
        static string id = "";
        public MenuManagement()
        {
            InitializeComponent();

        }
        private void loadData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();

                    string q = @"SELECT ProductId, ProductName, Description, Category, Price, StockQuantity 
                         FROM Product";

                    SqlDataAdapter sda = new SqlDataAdapter(q, con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);


                    dataGridView1.DataSource = null;
                    dataGridView1.Rows.Clear();

                    dataGridView1.AutoGenerateColumns = false;
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void MapColumns()
        {

            dataGridView1.Columns["pid"].DataPropertyName = "ProductId";
            dataGridView1.Columns["pName"].DataPropertyName = "ProductName";
            dataGridView1.Columns["description"].DataPropertyName = "Description";
            dataGridView1.Columns["Category"].DataPropertyName = "Category";
            dataGridView1.Columns["price"].DataPropertyName = "Price";
            dataGridView1.Columns["stockQty"].DataPropertyName = "StockQuantity";
        }

        private void MenuManagement_Load(object sender, EventArgs e)
        {
            loadData();
            MapColumns();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            string columnName = dataGridView1.Columns[e.ColumnIndex].Name;

            if (columnName == "editBtn")
            {
                id = dataGridView1.Rows[e.RowIndex].Cells["pid"].Value.ToString();
                usernameTxtBox.Text = dataGridView1.Rows[e.RowIndex].Cells["pName"].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["description"].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells["stockQty"].Value.ToString();
                textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells["price"].Value.ToString();

            }
            if (columnName == "deleteBtn")
            {
                DeleteProduct(e.RowIndex);
            }


        }
        private void DeleteProduct(int rowIndex)
        {
            try
            {
                DialogResult result = MessageBox.Show(
                    "Are you sure you want to delete this product?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (result == DialogResult.Yes)
                {
                    int id = Convert.ToInt32(dataGridView1.Rows[rowIndex].Cells["pid"].Value);

                    using (SqlConnection con = new SqlConnection(conStr))
                    {
                        con.Open();

                        string q = "DELETE FROM Product WHERE ProductId = @id";
                        SqlCommand cmd = new SqlCommand(q, con);
                        cmd.Parameters.AddWithValue("@id", id);

                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Product deleted successfully!");

                    loadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {


                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();

                    string q = @"UPDATE Product 
                         SET ProductName = @name,
                             Description = @desc,
                             Price = @price,
                             StockQuantity = @stock
                         WHERE ProductId = @id";

                    SqlCommand cmd = new SqlCommand(q, con);

                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@name", usernameTxtBox.Text);
                    cmd.Parameters.AddWithValue("@desc", textBox3.Text);
                    cmd.Parameters.AddWithValue("@price", Convert.ToDecimal(textBox5.Text));
                    cmd.Parameters.AddWithValue("@stock", Convert.ToInt32(textBox4.Text));

                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                        MessageBox.Show("Product updated successfully!");
                    else
                        MessageBox.Show("Update failed!");

                    loadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void signIn_Click(object sender, EventArgs e)
        {
            try
            {
               
                if (string.IsNullOrWhiteSpace(textBox8.Text) ||
                    string.IsNullOrWhiteSpace(textBox7.Text) ||
                    string.IsNullOrWhiteSpace(textBox9.Text) ||   
                    string.IsNullOrWhiteSpace(textBox6.Text) ||
                    string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("Please fill all fields!");
                    return;
                }

                decimal price;
                int stock;

              
                if (!decimal.TryParse(textBox9.Text, out price))
                {
                    MessageBox.Show("Invalid Price!");
                    return;
                }

                
                if (!int.TryParse(textBox6.Text, out stock))
                {
                    MessageBox.Show("Invalid Stock!");
                    return;
                }

              
                int isAvailable = stock > 0 ? 1 : 0;

                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();

                    string q = @"INSERT INTO Product 
                         (ProductName, Description, Category, Price, StockQuantity, IsAvailable)
                         VALUES 
                         (@name, @desc, @cat, @price, @stock, @isAvailable)";

                    SqlCommand cmd = new SqlCommand(q, con);

                    cmd.Parameters.AddWithValue("@name", textBox8.Text.Trim());
                    cmd.Parameters.AddWithValue("@desc", textBox7.Text.Trim());
                    cmd.Parameters.AddWithValue("@cat", textBox2.Text.Trim()); 
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@stock", stock);
                    cmd.Parameters.AddWithValue("@isAvailable", isAvailable);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Product added successfully!");

                   
                    usernameTxtBox.Clear();
                    textBox3.Clear();
                    textBox2.Clear();   
                    textBox5.Clear();
                    textBox4.Clear();

                    loadData(); 
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
