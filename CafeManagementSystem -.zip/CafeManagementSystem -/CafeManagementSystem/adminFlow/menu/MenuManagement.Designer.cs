﻿namespace CafeManagementSystem.adminFlow.menu
{
    partial class MenuManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            usernameTxtBox = new TextBox();
            panel1 = new Panel();
            label10 = new Label();
            textBox9 = new TextBox();
            label2 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            textBox2 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            dataGridView1 = new DataGridView();
            pid = new DataGridViewTextBoxColumn();
            pName = new DataGridViewTextBoxColumn();
            description = new DataGridViewTextBoxColumn();
            Category = new DataGridViewTextBoxColumn();
            price = new DataGridViewTextBoxColumn();
            stockQty = new DataGridViewTextBoxColumn();
            editBtn = new DataGridViewButtonColumn();
            deleteBtn = new DataGridViewButtonColumn();
            signIn = new Button();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            button1 = new Button();
            textBox5 = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(639, 65);
            label1.Name = "label1";
            label1.Size = new Size(425, 61);
            label1.TabIndex = 1;
            label1.Text = "Manage Products";
            // 
            // usernameTxtBox
            // 
            usernameTxtBox.BackColor = Color.FromArgb(18, 18, 18);
            usernameTxtBox.BorderStyle = BorderStyle.FixedSingle;
            usernameTxtBox.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            usernameTxtBox.ForeColor = Color.FromArgb(166, 166, 166);
            usernameTxtBox.Location = new Point(2057, 352);
            usernameTxtBox.Multiline = true;
            usernameTxtBox.Name = "usernameTxtBox";
            usernameTxtBox.Size = new Size(392, 78);
            usernameTxtBox.TabIndex = 4;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(23, 23, 23);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(label10);
            panel1.Controls.Add(textBox9);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox6);
            panel1.Controls.Add(textBox7);
            panel1.Controls.Add(textBox8);
            panel1.Controls.Add(dataGridView1);
            panel1.Location = new Point(41, 178);
            panel1.Name = "panel1";
            panel1.Size = new Size(1740, 1221);
            panel1.TabIndex = 7;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(229, 825);
            label10.Name = "label10";
            label10.Size = new Size(88, 40);
            label10.TabIndex = 28;
            label10.Text = "Price";
            // 
            // textBox9
            // 
            textBox9.BackColor = Color.FromArgb(18, 18, 18);
            textBox9.BorderStyle = BorderStyle.FixedSingle;
            textBox9.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox9.ForeColor = Color.FromArgb(166, 166, 166);
            textBox9.Location = new Point(374, 806);
            textBox9.Multiline = true;
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(392, 78);
            textBox9.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(173, 1008);
            label2.Name = "label2";
            label2.Size = new Size(144, 40);
            label2.TabIndex = 26;
            label2.Text = "Category";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(1001, 828);
            label7.Name = "label7";
            label7.Size = new Size(96, 40);
            label7.TabIndex = 25;
            label7.Text = "Stock";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(940, 638);
            label8.Name = "label8";
            label8.Size = new Size(179, 40);
            label8.TabIndex = 24;
            label8.Text = "Description";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(173, 625);
            label9.Name = "label9";
            label9.Size = new Size(100, 40);
            label9.TabIndex = 23;
            label9.Text = "Name";
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(18, 18, 18);
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.ForeColor = Color.FromArgb(166, 166, 166);
            textBox2.Location = new Point(374, 992);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(392, 78);
            textBox2.TabIndex = 22;
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.FromArgb(18, 18, 18);
            textBox6.BorderStyle = BorderStyle.FixedSingle;
            textBox6.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox6.ForeColor = Color.FromArgb(166, 166, 166);
            textBox6.Location = new Point(1204, 806);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(392, 78);
            textBox6.TabIndex = 21;
            // 
            // textBox7
            // 
            textBox7.BackColor = Color.FromArgb(18, 18, 18);
            textBox7.BorderStyle = BorderStyle.FixedSingle;
            textBox7.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox7.ForeColor = Color.FromArgb(166, 166, 166);
            textBox7.Location = new Point(1204, 619);
            textBox7.Multiline = true;
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(392, 78);
            textBox7.TabIndex = 20;
            // 
            // textBox8
            // 
            textBox8.BackColor = Color.FromArgb(18, 18, 18);
            textBox8.BorderStyle = BorderStyle.FixedSingle;
            textBox8.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox8.ForeColor = Color.FromArgb(166, 166, 166);
            textBox8.Location = new Point(374, 619);
            textBox8.Multiline = true;
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(392, 78);
            textBox8.TabIndex = 19;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(38, 38, 38);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { pid, pName, description, Category, price, stockQty, editBtn, deleteBtn });
            dataGridView1.GridColor = SystemColors.ControlDark;
            dataGridView1.Location = new Point(69, 34);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.Size = new Size(1592, 466);
            dataGridView1.TabIndex = 7;
            dataGridView1.CellClick += dataGridView1_CellClick;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // pid
            // 
            pid.HeaderText = "Id";
            pid.MinimumWidth = 10;
            pid.Name = "pid";
            pid.Width = 200;
            // 
            // pName
            // 
            pName.HeaderText = "ProductName";
            pName.MinimumWidth = 10;
            pName.Name = "pName";
            pName.Width = 200;
            // 
            // description
            // 
            description.HeaderText = "Description";
            description.MinimumWidth = 10;
            description.Name = "description";
            description.Width = 200;
            // 
            // Category
            // 
            Category.HeaderText = "Category";
            Category.MinimumWidth = 10;
            Category.Name = "Category";
            Category.Width = 200;
            // 
            // price
            // 
            price.HeaderText = "Price";
            price.MinimumWidth = 10;
            price.Name = "price";
            price.Width = 200;
            // 
            // stockQty
            // 
            stockQty.HeaderText = "Stock";
            stockQty.MinimumWidth = 10;
            stockQty.Name = "stockQty";
            stockQty.Width = 200;
            // 
            // editBtn
            // 
            editBtn.HeaderText = "Edit";
            editBtn.MinimumWidth = 10;
            editBtn.Name = "editBtn";
            editBtn.Text = "Edit";
            editBtn.UseColumnTextForButtonValue = true;
            editBtn.Width = 200;
            // 
            // deleteBtn
            // 
            deleteBtn.HeaderText = "Delete";
            deleteBtn.MinimumWidth = 10;
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Text = "Delete";
            deleteBtn.UseColumnTextForButtonValue = true;
            deleteBtn.Width = 200;
            // 
            // signIn
            // 
            signIn.BackColor = Color.FromArgb(236, 19, 19);
            signIn.Cursor = Cursors.Hand;
            signIn.FlatStyle = FlatStyle.Flat;
            signIn.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signIn.ForeColor = Color.White;
            signIn.Location = new Point(604, 1429);
            signIn.Name = "signIn";
            signIn.Size = new Size(606, 78);
            signIn.TabIndex = 8;
            signIn.Text = "Add New Product";
            signIn.UseVisualStyleBackColor = false;
            signIn.Click += signIn_Click;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(18, 18, 18);
            textBox3.BorderStyle = BorderStyle.FixedSingle;
            textBox3.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.ForeColor = Color.FromArgb(166, 166, 166);
            textBox3.Location = new Point(2057, 477);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(392, 78);
            textBox3.TabIndex = 11;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(18, 18, 18);
            textBox4.BorderStyle = BorderStyle.FixedSingle;
            textBox4.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.ForeColor = Color.FromArgb(166, 166, 166);
            textBox4.Location = new Point(2057, 590);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(392, 78);
            textBox4.TabIndex = 12;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(236, 19, 19);
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(2115, 922);
            button1.Name = "button1";
            button1.Size = new Size(271, 78);
            button1.TabIndex = 13;
            button1.Text = "Edit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.FromArgb(18, 18, 18);
            textBox5.BorderStyle = BorderStyle.FixedSingle;
            textBox5.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox5.ForeColor = Color.FromArgb(166, 166, 166);
            textBox5.Location = new Point(2057, 725);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(392, 78);
            textBox5.TabIndex = 14;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(1856, 358);
            label3.Name = "label3";
            label3.Size = new Size(100, 40);
            label3.TabIndex = 15;
            label3.Text = "Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(1821, 492);
            label4.Name = "label4";
            label4.Size = new Size(179, 40);
            label4.TabIndex = 16;
            label4.Text = "Description";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(1879, 596);
            label5.Name = "label5";
            label5.Size = new Size(96, 40);
            label5.TabIndex = 17;
            label5.Text = "Stock";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(1912, 744);
            label6.Name = "label6";
            label6.Size = new Size(88, 40);
            label6.TabIndex = 18;
            label6.Text = "Price";
            // 
            // MenuManagement
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(2492, 1536);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textBox5);
            Controls.Add(button1);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(signIn);
            Controls.Add(panel1);
            Controls.Add(usernameTxtBox);
            Controls.Add(label1);
            Name = "MenuManagement";
            Text = "MenuManagement";
            Load += MenuManagement_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox usernameTxtBox;
        private Panel panel1;
        private DataGridView dataGridView1;
        private Button signIn;
        private DataGridViewTextBoxColumn pid;
        private DataGridViewTextBoxColumn pName;
        private DataGridViewTextBoxColumn description;
        private DataGridViewTextBoxColumn Category;
        private DataGridViewTextBoxColumn price;
        private DataGridViewTextBoxColumn stockQty;
        private DataGridViewButtonColumn editBtn;
        private DataGridViewButtonColumn deleteBtn;
        private TextBox textBox1;
        private TextBox textBox3;
        private TextBox textBox4;
        private Button button1;
        private TextBox textBox5;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label10;
        private TextBox textBox9;
        private Label label2;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox textBox2;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
    }
}