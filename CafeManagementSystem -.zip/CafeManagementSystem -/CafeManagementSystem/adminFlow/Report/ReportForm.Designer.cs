﻿namespace CafeManagementSystem.adminFlow.Report
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            signIn = new Button();
            panel1 = new Panel();
            dataGridView1 = new DataGridView();
            label3 = new Label();
            label2 = new Label();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(585, -146);
            label1.Name = "label1";
            label1.Size = new Size(424, 61);
            label1.TabIndex = 15;
            label1.Text = "Bill And Payment";
            // 
            // signIn
            // 
            signIn.BackColor = Color.FromArgb(236, 19, 19);
            signIn.Cursor = Cursors.Hand;
            signIn.FlatStyle = FlatStyle.Flat;
            signIn.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signIn.ForeColor = Color.White;
            signIn.Location = new Point(550, 1218);
            signIn.Name = "signIn";
            signIn.Size = new Size(606, 78);
            signIn.TabIndex = 17;
            signIn.Text = "Proceed";
            signIn.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(23, 23, 23);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(dateTimePicker2);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(dataGridView1);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(-13, -33);
            panel1.Name = "panel1";
            panel1.Size = new Size(1740, 1221);
            panel1.TabIndex = 16;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(38, 38, 38);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = SystemColors.ControlDark;
            dataGridView1.Location = new Point(57, 260);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.Size = new Size(1658, 370);
            dataGridView1.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(127, 118);
            label3.Name = "label3";
            label3.Size = new Size(92, 40);
            label3.TabIndex = 4;
            label3.Text = "From";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(93, 99);
            label2.Name = "label2";
            label2.Size = new Size(0, 40);
            label2.TabIndex = 6;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(310, 118);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(400, 39);
            dateTimePicker1.TabIndex = 8;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(1100, 118);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(400, 39);
            dateTimePicker2.TabIndex = 11;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(917, 118);
            label4.Name = "label4";
            label4.Size = new Size(53, 40);
            label4.TabIndex = 9;
            label4.Text = "To";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(883, 99);
            label5.Name = "label5";
            label5.Size = new Size(0, 40);
            label5.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(153, 763);
            label6.Name = "label6";
            label6.Size = new Size(193, 40);
            label6.TabIndex = 12;
            label6.Text = "Total Orders";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(153, 857);
            label7.Name = "label7";
            label7.Size = new Size(274, 40);
            label7.TabIndex = 13;
            label7.Text = "Completed Orders";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(153, 953);
            label8.Name = "label8";
            label8.Size = new Size(217, 40);
            label8.TabIndex = 14;
            label8.Text = "Total Revenue";
            // 
            // ReportForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1759, 1349);
            Controls.Add(label1);
            Controls.Add(signIn);
            Controls.Add(panel1);
            Name = "ReportForm";
            Text = "ReportForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button signIn;
        private Panel panel1;
        private Label label8;
        private Label label7;
        private Label label6;
        private DateTimePicker dateTimePicker2;
        private Label label4;
        private Label label5;
        private DateTimePicker dateTimePicker1;
        private DataGridView dataGridView1;
        private Label label3;
        private Label label2;
    }
}