﻿namespace CafeManagementSystem.adminFlow.Setting
{
    partial class SettingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingForm));
            panel1 = new Panel();
            textBox4 = new TextBox();
            label4 = new Label();
            textBox5 = new TextBox();
            label6 = new Label();
            textBox3 = new TextBox();
            label5 = new Label();
            textBox2 = new TextBox();
            label3 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            signIn = new Button();
            usernameTxtBox = new TextBox();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(23, 23, 23);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(textBox4);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(textBox5);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(signIn);
            panel1.Controls.Add(usernameTxtBox);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(133, 79);
            panel1.Name = "panel1";
            panel1.Size = new Size(1545, 966);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(18, 18, 18);
            textBox4.BorderStyle = BorderStyle.FixedSingle;
            textBox4.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.ForeColor = Color.FromArgb(166, 166, 166);
            textBox4.Location = new Point(1038, 584);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(474, 78);
            textBox4.TabIndex = 18;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(845, 603);
            label4.Name = "label4";
            label4.Size = new Size(147, 40);
            label4.TabIndex = 17;
            label4.Text = "Currency";
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.FromArgb(18, 18, 18);
            textBox5.BorderStyle = BorderStyle.FixedSingle;
            textBox5.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox5.ForeColor = Color.FromArgb(166, 166, 166);
            textBox5.Location = new Point(274, 603);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(474, 78);
            textBox5.TabIndex = 16;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(21, 622);
            label6.Name = "label6";
            label6.Size = new Size(258, 40);
            label6.TabIndex = 15;
            label6.Text = "Delivery Charges";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(18, 18, 18);
            textBox3.BorderStyle = BorderStyle.FixedSingle;
            textBox3.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.ForeColor = Color.FromArgb(166, 166, 166);
            textBox3.Location = new Point(1038, 447);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(474, 78);
            textBox3.TabIndex = 14;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(889, 464);
            label5.Name = "label5";
            label5.Size = new Size(69, 40);
            label5.TabIndex = 13;
            label5.Text = "Tax";
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(18, 18, 18);
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.ForeColor = Color.FromArgb(166, 166, 166);
            textBox2.Location = new Point(274, 479);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(474, 78);
            textBox2.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(34, 496);
            label3.Name = "label3";
            label3.Size = new Size(204, 40);
            label3.TabIndex = 11;
            label3.Text = "Cafe Address";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(18, 18, 18);
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.ForeColor = Color.FromArgb(166, 166, 166);
            textBox1.Location = new Point(1038, 327);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(474, 78);
            textBox1.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(782, 333);
            label1.Name = "label1";
            label1.Size = new Size(250, 40);
            label1.TabIndex = 9;
            label1.Text = "Contact Number";
            // 
            // signIn
            // 
            signIn.BackColor = Color.FromArgb(236, 19, 19);
            signIn.Cursor = Cursors.Hand;
            signIn.FlatStyle = FlatStyle.Flat;
            signIn.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signIn.ForeColor = Color.White;
            signIn.Location = new Point(457, 832);
            signIn.Name = "signIn";
            signIn.Size = new Size(606, 78);
            signIn.TabIndex = 6;
            signIn.Text = "Edit";
            signIn.UseVisualStyleBackColor = false;
            signIn.Click += signIn_Click;
            // 
            // usernameTxtBox
            // 
            usernameTxtBox.BackColor = Color.FromArgb(18, 18, 18);
            usernameTxtBox.BorderStyle = BorderStyle.FixedSingle;
            usernameTxtBox.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            usernameTxtBox.ForeColor = Color.FromArgb(166, 166, 166);
            usernameTxtBox.Location = new Point(274, 327);
            usernameTxtBox.Multiline = true;
            usernameTxtBox.Name = "usernameTxtBox";
            usernameTxtBox.Size = new Size(474, 78);
            usernameTxtBox.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(77, 333);
            label2.Name = "label2";
            label2.Size = new Size(174, 40);
            label2.TabIndex = 2;
            label2.Text = "Cafe Name";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(614, 21);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(280, 268);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // SettingForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1815, 1295);
            Controls.Add(panel1);
            Name = "SettingForm";
            Text = "SettingForm";
            Load += SettingForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button signIn;
        private TextBox usernameTxtBox;
        private Label label2;
        private PictureBox pictureBox1;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox1;
        private Label label1;
        private TextBox textBox4;
        private Label label4;
        private TextBox textBox5;
        private Label label6;
        private TextBox textBox3;
        private Label label5;
    }
}