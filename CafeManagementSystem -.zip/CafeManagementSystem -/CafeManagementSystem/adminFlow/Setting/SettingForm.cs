﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CafeManagementSystem.adminFlow.Setting
{
    public partial class SettingForm : Form
    {
        static string conStr = "Data Source=MAC4C34\\SQLEXPRESS;Initial Catalog=CafeManagementSystem;Integrated Security=True";
        static SqlConnection con = new SqlConnection(conStr);
        public SettingForm()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SettingForm_Load(object sender, EventArgs e)
        {
            LoadSettings();

        }
        private void LoadSettings()
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = "SELECT SettingKey, SettingValue FROM Settings";
                SqlCommand cmd = new SqlCommand(q, con);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string key = reader["SettingKey"].ToString();
                    string value = reader["SettingValue"].ToString();

                    if (key == "CafeName") usernameTxtBox.Text = value;
                    if (key == "ContactNumber") textBox1.Text = value;
                    if (key == "CafeAddress") textBox2.Text = value;
                    if (key == "Tax") textBox3.Text = value;
                    if (key == "DeliveryCharges") textBox5.Text = value;
                    if (key == "Currency") textBox4.Text = value;
                }
            }
        }

        private void signIn_Click(object sender, EventArgs e)
        {
            try
            {
                UpdateSetting("CafeName", usernameTxtBox.Text);
                UpdateSetting("ContactNumber", textBox1.Text);
                UpdateSetting("CafeAddress", textBox2.Text);
                UpdateSetting("Tax", textBox3.Text);
                UpdateSetting("DeliveryCharges", textBox5.Text);
                UpdateSetting("Currency", textBox4.Text);

                MessageBox.Show("Settings updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void UpdateSetting(string key, string value)
        {
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string q = "UPDATE Settings SET SettingValue = @value WHERE SettingKey = @key";

                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@key", key);
                cmd.Parameters.AddWithValue("@value", value);

                cmd.ExecuteNonQuery();
            }
        }
    }
}
