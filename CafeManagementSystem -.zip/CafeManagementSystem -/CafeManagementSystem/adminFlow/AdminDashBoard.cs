﻿using CafeManagementSystem.adminFlow.menu;
using CafeManagementSystem.adminFlow.orderManagement;
using CafeManagementSystem.adminFlow.Setting;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeManagementSystem.adminFlow
{
    public partial class AdminDashBoard : Form
    {
        public AdminDashBoard()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void MenuManageMentBtn_Click(object sender, EventArgs e)
        {
            MenuManagement menuManagement = new MenuManagement();
            menuManagement.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OrderManagemnt orderManagemnt = new OrderManagemnt();
            orderManagemnt.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SettingForm settingForm = new SettingForm();
            settingForm.Show();
            this.Hide();
        }
    }
}
