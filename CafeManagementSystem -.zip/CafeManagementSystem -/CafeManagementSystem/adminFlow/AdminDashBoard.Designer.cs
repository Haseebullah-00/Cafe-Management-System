﻿namespace CafeManagementSystem.adminFlow
{
    partial class AdminDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button4 = new Button();
            button1 = new Button();
            MenuManageMentBtn = new Button();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            button5 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(31, 31, 31);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(MenuManageMentBtn);
            panel1.Location = new Point(53, 258);
            panel1.Name = "panel1";
            panel1.Size = new Size(1715, 1114);
            panel1.TabIndex = 3;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(38, 38, 38);
            button4.Cursor = Cursors.Hand;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Times New Roman", 22.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Location = new Point(1145, 167);
            button4.Name = "button4";
            button4.Size = new Size(410, 365);
            button4.TabIndex = 11;
            button4.Text = "Settings";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(38, 38, 38);
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Times New Roman", 22.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(641, 167);
            button1.Name = "button1";
            button1.Size = new Size(410, 365);
            button1.TabIndex = 8;
            button1.Text = "Order Management";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // MenuManageMentBtn
            // 
            MenuManageMentBtn.BackColor = Color.FromArgb(38, 38, 38);
            MenuManageMentBtn.Cursor = Cursors.Hand;
            MenuManageMentBtn.FlatStyle = FlatStyle.Flat;
            MenuManageMentBtn.Font = new Font("Times New Roman", 22.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            MenuManageMentBtn.ForeColor = Color.White;
            MenuManageMentBtn.Location = new Point(90, 167);
            MenuManageMentBtn.Name = "MenuManageMentBtn";
            MenuManageMentBtn.Size = new Size(410, 365);
            MenuManageMentBtn.TabIndex = 7;
            MenuManageMentBtn.Text = "Menu Management";
            MenuManageMentBtn.UseVisualStyleBackColor = false;
            MenuManageMentBtn.Click += MenuManageMentBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(335, 86);
            label1.Name = "label1";
            label1.Size = new Size(178, 61);
            label1.TabIndex = 0;
            label1.Text = "Admin";
            label1.Click += label1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.adminIcon;
            pictureBox2.Location = new Point(53, 27);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(246, 196);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(18, 18, 18);
            button5.Cursor = Cursors.Hand;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Times New Roman", 13.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.Location = new Point(1308, 65);
            button5.Name = "button5";
            button5.Size = new Size(347, 101);
            button5.TabIndex = 9;
            button5.Text = "Sign Out";
            button5.UseVisualStyleBackColor = false;
            // 
            // AdminDashBoard
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1820, 1465);
            Controls.Add(button5);
            Controls.Add(pictureBox2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Name = "AdminDashBoard";
            Text = "AdminDashBoard";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox2;
        private Button MenuManageMentBtn;
        private Button button1;
        private Button button4;
        private Button button5;
    }
}