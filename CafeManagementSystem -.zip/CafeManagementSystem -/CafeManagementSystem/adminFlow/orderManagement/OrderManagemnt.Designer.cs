﻿namespace CafeManagementSystem.adminFlow.orderManagement
{
    partial class OrderManagemnt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            signIn = new Button();
            label2 = new Label();
            comboBox1 = new ComboBox();
            label3 = new Label();
            dataGridView1 = new DataGridView();
            panel1 = new Panel();
            orderId = new DataGridViewTextBoxColumn();
            userName = new DataGridViewTextBoxColumn();
            orderDate = new DataGridViewTextBoxColumn();
            totalAmount = new DataGridViewTextBoxColumn();
            status = new DataGridViewComboBoxColumn();
            Detail = new DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(639, 47);
            label1.Name = "label1";
            label1.Size = new Size(386, 61);
            label1.TabIndex = 9;
            label1.Text = "Manage Orders";
            // 
            // signIn
            // 
            signIn.BackColor = Color.FromArgb(236, 19, 19);
            signIn.Cursor = Cursors.Hand;
            signIn.FlatStyle = FlatStyle.Flat;
            signIn.Font = new Font("Times New Roman", 15F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signIn.ForeColor = Color.White;
            signIn.Location = new Point(604, 1411);
            signIn.Name = "signIn";
            signIn.Size = new Size(606, 78);
            signIn.TabIndex = 11;
            signIn.Text = "Update Status";
            signIn.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(93, 99);
            label2.Name = "label2";
            label2.Size = new Size(0, 40);
            label2.TabIndex = 6;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.FromArgb(18, 18, 18);
            comboBox1.Font = new Font("Times New Roman", 19.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.ForeColor = Color.FromArgb(166, 166, 166);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(578, 99);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(433, 69);
            comboBox1.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(387, 109);
            label3.Name = "label3";
            label3.Size = new Size(104, 40);
            label3.TabIndex = 4;
            label3.Text = "Status";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(38, 38, 38);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { orderId, userName, orderDate, totalAmount, status, Detail });
            dataGridView1.GridColor = SystemColors.ControlDark;
            dataGridView1.Location = new Point(57, 260);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.Size = new Size(1592, 894);
            dataGridView1.TabIndex = 7;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(23, 23, 23);
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(dataGridView1);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(comboBox1);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(41, 160);
            panel1.Name = "panel1";
            panel1.Size = new Size(1740, 1221);
            panel1.TabIndex = 10;
            // 
            // orderId
            // 
            orderId.HeaderText = "OrderId";
            orderId.MinimumWidth = 10;
            orderId.Name = "orderId";
            orderId.Width = 200;
            // 
            // userName
            // 
            userName.HeaderText = "Customer";
            userName.MinimumWidth = 10;
            userName.Name = "userName";
            userName.Width = 200;
            // 
            // orderDate
            // 
            orderDate.HeaderText = "OrderDate";
            orderDate.MinimumWidth = 10;
            orderDate.Name = "orderDate";
            orderDate.Width = 200;
            // 
            // totalAmount
            // 
            totalAmount.HeaderText = "Amount";
            totalAmount.MinimumWidth = 10;
            totalAmount.Name = "totalAmount";
            totalAmount.Width = 200;
            // 
            // status
            // 
            status.HeaderText = "Status";
            status.MinimumWidth = 10;
            status.Name = "status";
            status.Width = 200;
            // 
            // Detail
            // 
            Detail.HeaderText = "Detail";
            Detail.MinimumWidth = 10;
            Detail.Name = "Detail";
            Detail.Text = "Detail";
            Detail.UseColumnTextForButtonValue = true;
            Detail.Width = 200;
            // 
            // OrderManagemnt
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1823, 1536);
            Controls.Add(label1);
            Controls.Add(panel1);
            Controls.Add(signIn);
            Name = "OrderManagemnt";
            Text = "OrderManagemnt";
            Load += OrderManagemnt_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button signIn;
        private Label label2;
        private ComboBox comboBox1;
        private Label label3;
        private DataGridView dataGridView1;
        private Panel panel1;
        private DataGridViewTextBoxColumn orderId;
        private DataGridViewTextBoxColumn userName;
        private DataGridViewTextBoxColumn orderDate;
        private DataGridViewTextBoxColumn totalAmount;
        private DataGridViewComboBoxColumn status;
        private DataGridViewButtonColumn Detail;
    }
}