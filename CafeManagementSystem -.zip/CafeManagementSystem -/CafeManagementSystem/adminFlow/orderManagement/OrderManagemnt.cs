﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CafeManagementSystem.adminFlow.orderManagement
{
    public partial class OrderManagemnt : Form
    {
        static string conStr =
            "Data Source=MAC4C34\\SQLEXPRESS;Initial Catalog=CafeManagementSystem;Integrated Security=True";

        public OrderManagemnt()
        {
            InitializeComponent();
        }

        
        private void OrderManagemnt_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;

            SetupStatusComboBox();  
            LoadOrders();           

            dataGridView1.CurrentCellDirtyStateChanged += dataGridView1_CurrentCellDirtyStateChanged;
            dataGridView1.CellValueChanged += dataGridView1_CellValueChanged;
        }

    
        private void MapColumns()
        {
            dataGridView1.Columns["orderId"].DataPropertyName = "OrderId";
            dataGridView1.Columns["userName"].DataPropertyName = "Username";
            dataGridView1.Columns["orderDate"].DataPropertyName = "OrderDate";
            dataGridView1.Columns["totalAmount"].DataPropertyName = "TotalAmount";
            dataGridView1.Columns["status"].DataPropertyName = "Status";
        }

        
        private void LoadOrders()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();

                    string q = @"
                    SELECT 
                        O.OrderId,
                        L.Username,
                        O.OrderDate,
                        O.TotalAmount,
                        O.Status
                    FROM Orders O
                    INNER JOIN Login L ON O.CustomerId = L.Id";

                    SqlDataAdapter da = new SqlDataAdapter(q, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;

                    MapColumns();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
        private void SetupStatusComboBox()
        {
            DataGridViewComboBoxColumn col =
                (DataGridViewComboBoxColumn)dataGridView1.Columns["status"];

            col.Items.Clear();
            col.Items.Add("Pending");
            col.Items.Add("Preparing");
            col.Items.Add("Ready");
        }

        private void dataGridView1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dataGridView1.IsCurrentCellDirty)
            {
                dataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

       
        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (dataGridView1.Columns[e.ColumnIndex].Name == "status")
            {
                int orderId = Convert.ToInt32(
                    dataGridView1.Rows[e.RowIndex].Cells["orderId"].Value
                );

                string newStatus =
                    dataGridView1.Rows[e.RowIndex].Cells["status"].Value.ToString();

                UpdateStatus(orderId, newStatus);
            }
        }

      
        private void UpdateStatus(int orderId, string status)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("UpdateOrderStatus", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@OrderId", orderId);
                    cmd.Parameters.AddWithValue("@Status", status);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}